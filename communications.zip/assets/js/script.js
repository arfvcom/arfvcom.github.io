document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;
  document.querySelectorAll(".nav-link[data-page]").forEach(a => {
    if (a.dataset.page === page) a.classList.add("active");
  });

  const back = document.getElementById("backToTop");
  const updateBack = () => {
    if (back) back.style.display = window.scrollY > 400 ? "flex" : "none";
  };
  window.addEventListener("scroll", updateBack, { passive: true });
  updateBack();
  if (back) back.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });

  document.querySelectorAll("form[data-demo-form]").forEach(form => form.addEventListener("submit", e => {
    e.preventDefault();
    const success = form.querySelector(".form-success");
    if (success) {
      success.classList.remove("d-none");
      success.innerHTML = '<i class="fa-solid fa-circle-check me-2"></i>' +
        (document.documentElement.lang === "ar"
          ? "شكراً لك. تم استلام طلبك وسيتواصل معك فريقنا قريباً."
          : "Thank you. Your enquiry has been received. Our team will contact you shortly.");
    }
    form.reset();
  }));

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  // Never leave visitors behind a preloader if a slow CDN/resource delays the page.
  const hidePreloader = () => {
    const preloader = document.getElementById("fvPreloader");
    if (!preloader || preloader.classList.contains("is-hidden")) return;
    preloader.classList.add("is-hidden");
    window.setTimeout(() => preloader.remove(), 650);
  };
  window.addEventListener("load", () => window.setTimeout(hidePreloader, 250), { once: true });
  window.setTimeout(hidePreloader, 1800);
});


// Premium home slider controls: synchronized counter, progress and subtle pointer depth.
document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("fvHeroSlider");
  if (!slider || !window.bootstrap) return;
  const counter = slider.querySelector(".current-slide");
  const dots = slider.querySelectorAll(".pro-slider-dots button");
  const progress = slider.querySelector(".progress-active");
  const resetProgress = () => {
    if (!progress) return;
    progress.style.animation = "none";
    void progress.offsetWidth;
    progress.style.animation = "slideProgress 6.5s linear infinite";
  };
  slider.addEventListener("slid.bs.carousel", (event) => {
    const n = String(event.to + 1).padStart(2, "0");
    if (counter) counter.textContent = n;
    dots.forEach((d, i) => d.classList.toggle("active", i === event.to));
    resetProgress();
  });
  slider.addEventListener("slide.bs.carousel", resetProgress);
  resetProgress();
  if (window.matchMedia("(pointer:fine)").matches) {
    slider.addEventListener("pointermove", (e) => {
      const visual = slider.querySelector(".carousel-item.active .pro-hero-image");
      if (!visual) return;
      const r = slider.getBoundingClientRect();
      const x = (e.clientX-r.left)/r.width-.5;
      const y = (e.clientY-r.top)/r.height-.5;
      visual.style.transform = `perspective(1100px) rotateY(${x*-4}deg) rotateX(${y*2}deg)`;
    });
    slider.addEventListener("pointerleave", () => {
      const visual = slider.querySelector(".carousel-item.active .pro-hero-image");
      if (visual) visual.style.transform = "perspective(1100px) rotateY(-4deg)";
    });
  }
});
